#pragma once

void Hooks_Data_Commit(void);