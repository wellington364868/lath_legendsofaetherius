#include "skse64/NiLight.h"
