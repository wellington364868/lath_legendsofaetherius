#pragma once

void Hooks_Handlers_Init(void);
void Hooks_Handlers_Commit(void);
