#include "common/ISingleton.h"

//template <typename T> T * Singleton <T>::ms_Singleton = 0;